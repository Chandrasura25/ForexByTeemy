<?php $__env->startSection('content'); ?>
<div class="body">
    
    <form method="POST" action="<?php echo e(route('password.confirm')); ?>">
        <small class="text-light"><?php echo e(__('Please confirm your password before continuing.')); ?></small>
        <h2><?php echo e(__('Confirm Password')); ?></h2>
         <?php echo csrf_field(); ?>
           <div class="inputBox">
               <input id="password" type="password" class="<?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="current-password">
                <label for="password"><?php echo e(__('Password')); ?></label>
                <span class="invalid-feedback" role="alert">
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <strong><?php echo e($message); ?></strong>
                </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="inputBox">
                <input type="submit" value="<?php echo e(__('Confirm Password')); ?>">      
            </div>
            <div class="row mb-0">
                <?php if(Route::has('password.request')): ?>
                    <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                        <?php echo e(__('Forgot Your Password?')); ?>

                    </a>
                <?php endif; ?>
            </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ROQEEBAH\Desktop\laravel\forexByTeemy\resources\views/auth/passwords/confirm.blade.php ENDPATH**/ ?>